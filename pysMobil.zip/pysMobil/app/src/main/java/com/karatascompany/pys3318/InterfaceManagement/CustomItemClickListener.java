package com.karatascompany.pys3318.InterfaceManagement;

import com.karatascompany.pys3318.models.ProjectModel;

/**
 * Created by azizmahmud on 6.9.2018.
 */

public interface CustomItemClickListener {

    public void onItemClick(ProjectModel projectModel, int position);

}
