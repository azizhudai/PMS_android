package com.karatascompany.pys3318.poco;

/**
 * Created by azizmahmud on 22.3.2018.
 */

public class Task {


}
